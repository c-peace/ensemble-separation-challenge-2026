# Ensemble Benchmark 소용량 샘플

SynthSOD·URMP의 공개 validation 음원에서 각각 5초씩 추출했습니다.
각 장면의 mixture.wav와 악기별 정답 WAV를 함께 제공합니다.
44,100 Hz · mono · WAV float32이며 모든 트랙은 같은 구간·길이입니다.
추가 gain 조정, 리샘플링, 개별 악기 정규화는 하지 않았습니다.

- SynthSOD: sod_756_native — Cello, Viola, Violin (바이올린 2파트 병합)
- URMP: urmp_43 — Horn, Trombone, Trumpet, Tuba (트럼펫 2파트 병합)
- 정확한 원본 구간·파일 SHA256은 manifest.json에서 확인할 수 있습니다.

이 ZIP은 청취·입출력 형식 확인용입니다. baseline.ipynb/evaluate.ipynb가 사용하는
전체 dataset.zip을 대체하지 않습니다. 학습에 사용하거나 공식 leaderboard 점수를
이 샘플로 계산하지 마세요. 전체 평가용 30개 장면은 서버의 dataset.zip에 있습니다.

## 출처 및 라이선스

원본 배포의 출처·가공·라이선스 안내는 SOURCES.md에 그대로 포함했습니다.
이 샘플의 추가 가공은 모든 트랙에 동일한 5초 구간 자르기와 WAV 재포장입니다.
SynthSOD 부분: CC BY-SA 4.0 (샘플도 동일), https://doi.org/10.5281/zenodo.13759492
URMP 부분: CC0 1.0, https://doi.org/10.5061/dryad.ng3r749
SOURCES.md의 전체 데이터 규모 설명은 원본 배포에 대한 것으로 이 샘플의 크기가 아닙니다.
